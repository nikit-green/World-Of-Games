from live import *

print(welcome())
load_game()
